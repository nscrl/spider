#-*- coding: UTF-8 -*-
import chardet,MySQLdb
f = open("university_attr")
conn    = MySQLdb.connect('localhost','spider','spider','spiderDB', charset='utf8')
cur         = conn.cursor()
sql         = 'select en_abbr, cn_alias from university_info'
cur.execute(sql)
result = cur.fetchall()
db_abbr_list = [item[0] for item in result]
db_alias_list= [item[1] for item in result]
# print db_alias_list
# cur.close()
# conn.close()
key_word = []
alias_dict = {}
area_dict = {}
line = f.readline()
while line:
    line = f.readline()
    if line.isspace() or not len(line):
        continue 
    #print line,', ', type(line), chardet.detect(line)
    [areaCode, abbr, level, aliasStr] = line.split(":")
    aliasStr = aliasStr[:-1]
    aliasList = aliasStr.split()
    # print aliasList

    if abbr not in db_abbr_list:
        sql = 'insert into university_info(area_code, en_abbr, level, cn_alias)'+\
            "values('%s', '%s', '%s', '%s')" % (areaCode, abbr, level, aliasStr)
        cur.execute(sql)
    elif len(aliasStr) != db_alias_list[db_abbr_list.index(abbr)]:
        sql = 'update university_info set cn_alias = "%s" where en_abbr = "%s" ' % (aliasStr, abbr)
        cur.execute(sql)

    area_dict[abbr] = areaCode
    for var in aliasList:
        # print var
        key_word.append(var)
        alias_dict[var] = abbr
    
    # #key_word.append(line)
    # line = f.readline()
    
f.close()
conn.commit()
cur.close()
conn.close()

# print len(key_word), key_word, '\n'
# print len(alias_dict), alias_dict, '\n'
# print len(area_dict), area_dict
