def mycmp(a, b):
    if a > b:
        print a
    #sdfj;kl
    else:
        print b

mycmp(3,5)
